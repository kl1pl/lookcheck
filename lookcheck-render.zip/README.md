# LookCheck — Telegram-бот для сравнения цен

Шопинг-ассистент: ищет товары на 6 маркетплейсах, сравнивает цены, ловит фейковые скидки, проверяет продавца и накрутку отзывов, подбирает кэшбэк.

## Запуск на Render (бесплатно) — 5 минут

1. Создайте GitHub-репозиторий и загрузите в него все файлы этой папки.
2. Зайдите на **render.com** → **New** → **Web Service** → **Connect GitHub repository** → выберите репозиторий.
3. Render подхватит `render.yaml` автоматически. Добавьте секрет `BOT_TOKEN` (Environment → Secret File/Environment Variable):
   - токен от @BotFather, вида `123456:AA...`
4. Нажмите **Create Web Service** → Deploy.
5. Через 2–3 минуты бот работает. Напишите ему `/start`.

## Локально (для разработки)

```bash
pip install -r requirements.txt
cp .env.example .env   # впишите BOT_TOKEN
python -m bot.main
```

## Команды бота

`/start` · `/search <товар>` · `/fav` (избранное+трекер цен) · `/stats` (экономия) · `/promo` · `/history` · `/premium` · ЛЮБОЙ текст = поиск · фото = поиск по фото.

## Структура

- `bot/` — весь код (handlers, providers, services, db, models)
- `render.yaml` — конфиг бесплатного развёртывания
- `.env.example` — переменные окружения
- `requirements.txt` — зависимости

## Примечания

- Демо-режим (`PROVIDER_MODE=demo`) работает без ключей маркетплейсов: встроенный каталог товаров и отзывов.
- SQLite-хранилище в бесплатном Render переживает перезапуск не всегда (эфемерный диск) — для продакшена переключите `DATABASE_URL` на внешнюю БД.